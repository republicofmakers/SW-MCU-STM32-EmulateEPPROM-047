/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "st7735.h"
#include "GFX_FUNCTIONS.h"
#include "fonts.h"
#include "stdio.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

SPI_HandleTypeDef hspi1;

/* USER CODE BEGIN PV */
static const uint8_t SHT45_ADDR = 0x44 << 1; //7 bit addr with 1 bit for R/W
static const uint8_t SHT45_DataReg = 0xFD;

#define CRC8_POLYNOMIAL 0x31
#define CRC8_INIT 0xFF

#define FLASH_USER_START_ADDR  ((uint32_t)0x0800FC00) // last 1KB of 64KB

volatile uint8_t measure_requested = 0;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void Flash_WriteFloat(uint32_t address, float data) {
    HAL_FLASH_Unlock();

    HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, address, *(uint64_t*)&data);

    HAL_FLASH_Lock();
}

float Flash_ReadFloat(uint32_t address) {
    float value;
    memcpy(&value, (void*)address, sizeof(float));
    return value;
}

void Flash_ErasePage(uint32_t address) {
    HAL_FLASH_Unlock();

    FLASH_EraseInitTypeDef eraseInitStruct;
    uint32_t pageError = 0;

    eraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES;
    eraseInitStruct.Page = (address - FLASH_BASE) / FLASH_PAGE_SIZE;
    eraseInitStruct.NbPages = 1;

    HAL_FLASHEx_Erase(&eraseInitStruct, &pageError);

    HAL_FLASH_Lock();
}




void MeasureAndDisplay(void){

	HAL_StatusTypeDef ret;
				uint8_t buf[6];
				buf[0] = 0;
				buf[1] = 0;
				buf[2] = 0;
				buf[3] = 0;
				buf[4] = 0;
				buf[5] = 0;



			 	int numberofmeasurment = 100;
				float temp[numberofmeasurment-1];
				float hum[numberofmeasurment-1];


			    uint16_t current_byte;
			    uint8_t crc_bit;
			    uint8_t crc = CRC8_INIT;



			    float result1;
			    float result2;
			    float temp_sum = 0;
				float hum_sum = 0;
				uint8_t error_count = 0;
				uint8_t data_count = 0;
				float div_num;
				float final_temp;
				float final_hum;


				char Temperature[10];
				char Humidity[10];
				char Count[10];

			    float saved_temp = 0;
			    float saved_hum = 0;

    saved_temp = Flash_ReadFloat(FLASH_USER_START_ADDR);
    saved_hum = Flash_ReadFloat(FLASH_USER_START_ADDR + 8);


		  	  ST7735_FillScreen(ST7735_BLACK);
			  ST7735_WriteString(0, 0, "Previous", Font_11x18, ST7735_BLUE, ST7735_BLACK);
			  ST7735_WriteString(0, 30, "Temperature", Font_11x18, ST7735_BLUE, ST7735_BLACK);
			  sprintf(Temperature, "%.2f", saved_temp);
			  ST7735_WriteString(0, 60, Temperature, Font_11x18, ST7735_GREEN, ST7735_BLACK);
			  HAL_Delay(3000);


			  ST7735_FillScreen(ST7735_BLACK);
			  ST7735_WriteString(0, 0, "Previous", Font_11x18, ST7735_BLUE, ST7735_BLACK);
			  ST7735_WriteString(0, 30, "Humidity", Font_11x18, ST7735_BLUE, ST7735_BLACK);
			  sprintf(Humidity, "%.2f", saved_hum);
			  ST7735_WriteString(0, 60, Humidity, Font_11x18, ST7735_GREEN, ST7735_BLACK);
			  HAL_Delay(3000);


	  ST7735_FillScreen(ST7735_BLACK);
	 		  ST7735_WriteString(0, 0, "Measuring",	Font_11x18 , ST7735_RED, ST7735_BLACK);
	 		  ST7735_WriteString(60, 40, "%", Font_11x18, ST7735_GREEN, ST7735_BLACK);

	 		  error_count = 0;
	 		  data_count = 0;
	 		  temp_sum = 0;
	 		  hum_sum = 0;

	 		  for (int i = 0 ; i < numberofmeasurment; i++){

	 		  	  sprintf(Count, "%d", i);
	 		  	  ST7735_WriteString(0, 40, Count, Font_11x18, ST7735_GREEN, ST7735_BLACK);




	 		  	  buf[0] = SHT45_DataReg;

	 		  	  ret = HAL_I2C_Master_Transmit(&hi2c1, SHT45_ADDR, buf, 1, HAL_MAX_DELAY);
	 		  	  if(ret != HAL_OK)
	 		  	  {


	 		  		  ST7735_FillScreen(ST7735_BLACK);
	 		  		  ST7735_WriteString(0, 0, "RX ERROR", Font_11x18, ST7735_RED, ST7735_BLACK);
	 		  		  HAL_Delay(5000);


	 		  	  }
	 		  	  else
	 		  	  {


	 		  		  HAL_Delay(10);
	 		  		  ret = HAL_I2C_Master_Receive(&hi2c1, SHT45_ADDR, buf, 6, HAL_MAX_DELAY);
	 		  		  if(ret != HAL_OK)
	 		  		  	  {

	 		  			  ST7735_FillScreen(ST7735_BLACK);
	 		  			  ST7735_WriteString(0, 0, "RX ERROR", Font_11x18, ST7735_RED, ST7735_BLACK);
	 		  			  HAL_Delay(5000);


	 		  		  	  }
	 		  		  else
	 		  		  {


	 		  			  	  	  	  float number1 = buf[1] | buf[0] << 8;

	 		  			 			  result1 = (-45 + 175 *((number1/65535)));

	 		  			 			  temp[i] = result1;

	 		  			 			  //******************************************************************************


	 		  			 			  float number2 = buf[4] | buf[3] << 8;

	 		  			 			  result2 = (-6 + (125 *(number2/65535)));

	 		  			 			  hum[i] = result2;


	 		  			 			  //CRC  ************* CRC ***************** CRC
	 		  			 		      crc = CRC8_INIT;
	 		  			               int checksum1 = buf[2];
	 		  			 			  for (current_byte = 0; current_byte < 2; ++current_byte) {
	 		  			 			         crc ^= (buf[current_byte]);
	 		  			 			         for (crc_bit = 8; crc_bit > 0; --crc_bit) {
	 		  			 			             if (crc & 0x80)
	 		  			 			                 crc = (crc << 1) ^ CRC8_POLYNOMIAL;
	 		  			 			             else
	 		  			 			                 crc = (crc << 1);
	 		  			 			         }
	 		  			 			     }


	 		  			 			 int CRC_Check = 0 ;

	 		  			 		        if (crc != checksum1){
	 		  			 		        	CRC_Check = 1;
	 		  			 		        }
	 		  			 		        else{
	 		  			 		        	CRC_Check = 2;
	 		  			 		        }

	 		  			 		  //CRC2  ************* CRC2 ***************** CRC2

	 		  			     	        crc = CRC8_INIT;
	 		  			                 int checksum2 = buf[5];
	 		  			 		        for (current_byte = 3; current_byte < 5; ++current_byte) {
	 		  			 		            crc ^= (buf[current_byte]);
	 		  			 		            for (crc_bit = 8; crc_bit > 0; --crc_bit) {
	 		  			 		                if (crc & 0x80)
	 		  			 		                    crc = (crc << 1) ^ CRC8_POLYNOMIAL;
	 		  			 		                else
	 		  			 		                    crc = (crc << 1);
	 		  			 		            }
	 		  			 		        }




	 		  			 		          if (crc != checksum2){
	 		  			 		               if(CRC_Check == 1){
	 		  			 		            	CRC_Check = 3;
	 		  			 		            }
	 		  			 		               else{
	 		  			 		            	 CRC_Check = 4;
	 		  			 		               }
	 		  			 		          }
	 		  			 		            else{
	 		  			 			               if(CRC_Check == 1){
	 		  			 			            	 error_count = error_count + 1;
	 		  			 			            	 temp[i] = 0;
	 		  			                              hum[i] = 0;

	 		  			 			            }
	 		  			 			               else{
	 		  			 			            	 data_count = data_count + 1;
	 		  			 			               }
	 		  			 		            }



	 		  			 temp_sum = temp_sum + temp[i];

	 		  			 hum_sum = hum_sum + hum[i];
	 		  			 }



	 		  			 div_num = (numberofmeasurment-error_count);

	 		  			 final_temp = temp_sum / div_num;

	 		  			 final_hum = hum_sum / div_num;








	 		    }
	 		  }


	 		  		 if(data_count+error_count==numberofmeasurment){



	 		  			  ST7735_FillScreen(ST7735_BLACK);
	 		  			  ST7735_WriteString(0, 0, "Temperature", Font_11x18, ST7735_RED, ST7735_BLACK);
	 		  			  sprintf(Temperature, "%.2f", final_temp);
	 		  			  ST7735_WriteString(0, 40, Temperature, Font_11x18, ST7735_GREEN, ST7735_BLACK);
	 		  			  HAL_Delay(3000);


	 		  			  ST7735_FillScreen(ST7735_BLACK);
	 		  			  ST7735_WriteString(0, 0, "Humidity", Font_11x18, ST7735_RED, ST7735_BLACK);
	 		  			  sprintf(Humidity, "%.2f", final_hum);
	 		  			  ST7735_WriteString(0, 40, Humidity, Font_11x18, ST7735_GREEN, ST7735_BLACK);
	 		  			  HAL_Delay(3000);


	 		  		 }

	 		  		 else{
	 		  			  	  	  ST7735_FillScreen(ST7735_BLACK);
	 		  					  ST7735_WriteString(0, 0, "MEASUREMENT", Font_11x18, ST7735_RED, ST7735_BLACK);
	 		  					  ST7735_WriteString(0, 40,"ERROR", Font_11x18, ST7735_GREEN, ST7735_BLACK);
	 		  					  HAL_Delay(1000);
	 		  		 }



	 		  		Flash_ErasePage(FLASH_USER_START_ADDR);
	 		  		Flash_WriteFloat(FLASH_USER_START_ADDR, final_temp);
	 		  		Flash_WriteFloat(FLASH_USER_START_ADDR + 8, final_hum);


		  			  ST7735_FillScreen(ST7735_BLACK);
		  			  ST7735_WriteString(0, 0, "Press Button ", Font_11x18, ST7735_GREEN, ST7735_BLACK);
		  		      ST7735_WriteString(0, 30, "to Measure", Font_11x18, ST7735_GREEN, ST7735_BLACK);
		  		      ST7735_WriteString(0, 60, "Again", Font_11x18, ST7735_GREEN, ST7735_BLACK);

}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */

  for(int a =0;a<10;a++){
  	 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, 1);
  	 HAL_Delay(100);
  	 HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, 0);
  	 HAL_Delay(100);
  }
  	ST7735_Init();
       ST7735_FillScreen(ST7735_BLACK);
       ST7735_WriteString(0, 0, "Emulate EPPROM",	Font_11x18 , ST7735_RED, ST7735_BLACK);
       ST7735_WriteString(0, 30, "by Ceyhun Pempeci", Font_7x10, ST7735_GREEN, ST7735_BLACK);
       ST7735_WriteString(0, 50, "2025", Font_11x18, ST7735_BLUE, ST7735_BLACK);
       HAL_Delay(3000);



  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	    if (measure_requested)
	    {
	        measure_requested = 0;
	        MeasureAndDisplay();
	    }

	    HAL_Delay(10); // give time for other interrupts


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 20;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x10D19CE4;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_1LINE;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, CS_Pin|DC_Pin|RES_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : CS_Pin DC_Pin RES_Pin */
  GPIO_InitStruct.Pin = CS_Pin|DC_Pin|RES_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if(GPIO_Pin == GPIO_PIN_0)
    {
        measure_requested = 1;
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
